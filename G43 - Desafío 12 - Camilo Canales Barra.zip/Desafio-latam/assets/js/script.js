// 3 //

const element = document.getElementById("pintar");

function pintar(htmlElemet, color = "green") {
    if (htmlElemet.style.backgroundColor != color) {
        htmlElemet.style.backgroundColor = color;
    } else {
        htmlElemet.style.backgroundColor = "white";
    }
}

element.addEventListener("click", (e) => {
    pintar(e.target, "yellow");
});
