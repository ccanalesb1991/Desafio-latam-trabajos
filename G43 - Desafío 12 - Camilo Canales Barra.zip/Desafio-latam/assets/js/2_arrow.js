// 2 //

let suma = (a, b) => a + b;

suma(5, 5);
