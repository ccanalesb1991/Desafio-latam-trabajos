// 1 //

let suma = function (a, b, c) {
    return a + b + c;
};

suma(2, 0, 3);
